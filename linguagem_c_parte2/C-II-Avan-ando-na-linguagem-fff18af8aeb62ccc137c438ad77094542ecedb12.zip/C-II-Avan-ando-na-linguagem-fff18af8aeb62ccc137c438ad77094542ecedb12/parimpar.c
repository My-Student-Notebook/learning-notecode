int parimpar(int numero) {
  int resto = numero % 2;
  if(resto == 0) return 1;
  return 0;
}