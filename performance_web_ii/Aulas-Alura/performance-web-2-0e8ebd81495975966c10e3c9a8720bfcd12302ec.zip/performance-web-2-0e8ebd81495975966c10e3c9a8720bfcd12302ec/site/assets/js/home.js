if (navigator.userAgent.indexOf('Safari') > 1 && navigator.userAgent.indexOf('Edge') < 0) {
	document.documentElement.className += ' home-fundo-animado';
}