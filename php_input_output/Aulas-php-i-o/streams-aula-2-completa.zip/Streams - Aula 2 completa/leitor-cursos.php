<?php

$cursos = file('lista-cursos.txt');

var_dump($cursos);
