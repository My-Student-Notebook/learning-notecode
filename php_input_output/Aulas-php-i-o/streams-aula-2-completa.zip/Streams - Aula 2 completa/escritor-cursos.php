<?php

$curso = "\nDesign Patterns PHP II: Boas práticas de programação";

file_put_contents('cursos-php.txt', $curso, FILE_APPEND);
