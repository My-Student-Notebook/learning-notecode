<?php

echo file_get_contents('zip://arquivos.zip#lista-cursos.txt');
